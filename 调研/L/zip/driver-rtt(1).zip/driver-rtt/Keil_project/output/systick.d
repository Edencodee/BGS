./output/systick.o: ..\systick.c \
  ..\..\Firmware\CMSIS\GD\GD32C2x1\Include\gd32c2x1.h \
  D:\Users\16640\AppData\Local\Arm\Packs\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm23.h \
  ..\..\Firmware\CMSIS\GD\GD32C2x1\Include\system_gd32c2x1.h \
  ..\gd32c2x1_libopt.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_adc.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_cmp.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_crc.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_dbg.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_dma.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_exti.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_fmc.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_fwdgt.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_gpio.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_i2c.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_misc.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_pmu.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_rcu.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_rtc.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_spi.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_syscfg.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_timer.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_usart.h \
  ..\..\Firmware\GD32C2x1_standard_peripheral\Include\gd32c2x1_wwdgt.h \
  ..\..\Firmware\CMSIS\GD\GD32C2x1\Include\gd32c2x1_err_report.h \
  ..\systick.h
